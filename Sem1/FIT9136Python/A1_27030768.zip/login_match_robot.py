"""
This program prompts the user for a username and password 
until a valid and matching username and password is entered.
After 3 incorrect tries, the program asks the user to confirm 
they are not a robot, terminating on "Y" or nothing.

Author: Adrian Leong
"""

#set list of registered usernames
usernames = ["Ava", "Leo", "Raj", "Zoe", "Max", \
"Sam", "Eli", "Mia", "Ian", "Kim"]
#set list of registered passwords
passwords = ["12345", "abcde", "pass1", "qwert", \
"aaaaa", "zzzzz", "11111", "apple", "hello", "admin"]

#prompt for username and password until valid or 3 tries
remaining_attempts = 3
while (remaining_attempts > 0):
    #get input username and password
    user_login = input("Enter username: ")
    user_password = input("Enter password: ")

    #check if input is registered
    if user_login in usernames and user_password == passwords[usernames.index(user_login)]:
        #Successful login, terminate
        print(f"Login successful. Welcome {user_login} !")
        break
    else:
        #Incorrect login, retry
        remaining_attempts -= 1
        print(f"Login incorrect. Tries left: {remaining_attempts}")
        # 3 consecutive fails. Is user a robot?
        while (not remaining_attempts):
            robot_check = input("Are you a robot (Y/n)? ")
            if (robot_check == "Y" or robot_check == ""):
                # User entered "Y" or nothing, terminate
                remaining_attempts = -1 
            elif (robot_check == "n"):
                # User entered "n", give 3 more tries
                remaining_attempts = 3 
            else: 
                # try again
                continue
            


