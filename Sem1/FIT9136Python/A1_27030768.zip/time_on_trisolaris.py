"""
This program converts the number of seconds input by the user 
into its equivalent hours, minutes and seconds.
Then, the program allows for a variable rate of conversion between seconds,
minutes and hours, which it asks the user for.

Author: Adrian Leong
"""

#Get input time in seconds
input_seconds = int(input("TIME ON EARTH\nInput a time in seconds:\n"))

#set conversion rates
minutes_to_seconds = 60
hours_to_minutes = 60

#compute equivalent hours-minutes-seconds
time_hours = int(input_seconds/(hours_to_minutes*minutes_to_seconds))
time_minutes = int((input_seconds%(hours_to_minutes*minutes_to_seconds))/minutes_to_seconds)
time_seconds = int((input_seconds%(minutes_to_seconds)))

#print answer
print(f"\nThe time on Earth is {time_hours} hours {time_minutes} minutes and {time_seconds} seconds.")

#get modified unit conversion rates
minutes_to_seconds = int(input("\nTIME ON TRISOLARIS\nInput the number of seconds in a minute on Trisolaris:\n"))
hours_to_minutes = int(input("Input the number of minutes in an hour on Trisolaris:\n"))

#recompute equivalent hours-minutes-seconds
time_hours = int(input_seconds/(hours_to_minutes*minutes_to_seconds))
time_minutes = int((input_seconds%(hours_to_minutes*minutes_to_seconds))/minutes_to_seconds)
time_seconds = int((input_seconds%(minutes_to_seconds)))

#print new answer
print(f"\nThe time on Trisolaris is {time_hours} hours {time_minutes} minutes and {time_seconds} seconds.")



