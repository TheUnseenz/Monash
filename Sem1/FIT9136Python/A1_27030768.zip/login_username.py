"""
This program prompts the user for a username until a valid username is entered

Author: Adrian Leong
"""

#set list of registered usernames
usernames = {"Ava", "Leo", "Raj", "Zoe", "Max", "Sam", \
"Eli", "Mia", "Ian", "Kim"}

#prompt for username until a valid username is entered
while (True):
    #get input username
    user_login = input("Enter username: ")

    #check if input is registered
    if user_login in usernames:
        #Successful login, terminate
        print(f"Login successful. Welcome {user_login} !")
        break
    else:
        #Incorrect login, retry
        print("Login incorrect.")
