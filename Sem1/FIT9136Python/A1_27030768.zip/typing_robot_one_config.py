"""
The program takes in a user input string, and with a preset keyboard config,
it prints out the required robotic movements to type out the string in sequence

Author: Adrian Leong
"""
config = ["abcdefghijklm","nopqrstuvwxyz"]


def find_xy(char, config):
    """
    Input: 1 input character, and the keyboard layout
    Output: [x,y] 'coordinates' of the input character in the input config
    """
    for i in range(len(config)):
        for x in range(len(config[i])):
            if (char == config[i][j]):
                return [j,i]


def plan_movement(string, config): 
    """
    Input: an input string to be typed, and the keyboard layout
    Output: A string of movements to type out the string in sequence. 
    Starts from [0,0]. If cannot be typed, returns None
    u - go up
    d - go down
    l - go left
    r - go right
    p - press the key
    """
    current_position = [0,0]
    movement_string = ""
    # Plan consecutive movements for each letter in string
    for i in range(len(string)):
        # Find next position to move to
        next_position = find_xy(string[i], config)
        if (next_position is None): # String cannot be typed, not on keyboard
            return 

        # next_x - current_x -> number of "r" or "l" if negative
        # next_y - current_y -> number of "u" or "d" if negative
        movement_x = next_position[0] - current_position[0]
        movement_y = next_position[1] - current_position[1]
    
        # append number of r or l movements, 
        # then number of u or d movements, then p
        if movement_x > 0: # next position is to the right of current position
            movement_string += "r"*movement_x
        else: # next position is to the left of current position
            movement_string += "l"*abs(movement_x)
        if movement_y > 0: # next position is below current position
            movement_string += "d"*movement_y
        else: # next position is above current position
            movement_string += "u"*abs(movement_y)
        
        # press the key after moving there
        movement_string += "p" 

        # update current position after moving
        current_position = next_position
    return movement_string
        
# End of defined functions. Run the program
input_string = input("Enter a string to type: ")
movement_string = plan_movement(input_string, config)
if movement_string:
    #If movement string is not empty, print the sequence required to type it
    print("The robot must perform the following operations:\n"+movement_string)
else: 
    #If movement string is None, string contained a character not in keyboard
    print("The string cannot be typed out.")

    
    

