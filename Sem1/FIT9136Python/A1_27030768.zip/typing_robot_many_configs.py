"""
The program takes in a user input string, and with a set of preset 
keyboard configs, it computes the best keyboard config, then prints 
out the required robotic movements to type out the string in sequence

Author: Adrian Leong
"""
config0 = ["abcdefghijklm","nopqrstuvwxyz"]
config1 = ["789", "456", "123", "0.-"]
config2 = ["chunk", "vibex", "gymps", "fjord", "waltz"]
config3 = ["bemix", "vozhd", "grypt", "clunk", "waqfs"]
configs = [config0, config1, config2, config3]

def find_xy(char, config):
    """
    Input: 1 input character, and the keyboard layout
    Output: [x,y] 'coordinates' of the input character in the input config
    """
    for i in range(len(config)):
        for j in range(len(config[i])):
            if (char == config[i][j]):
                return [j,i]


def plan_movement(string, config): 
    """
    Input: an input string to be typed, and the keyboard layout
    Output: A string of movements to type out the string in sequence. 
    Starts from [0,0]. If cannot be typed, returns None
    u - go up
    d - go down
    l - go left
    r - go right
    p - press the key
    """
    current_position = [0,0]
    movement_string = ""
    # Plan consecutive movements for each letter in string
    for i in range(len(string)):
        # Find next position to move to
        next_position = find_xy(string[i], config)
        if (next_position is None): # String cannot be typed, not on keyboard
            return 

        # next_x - current_x -> number of "r" or "l" if negative
        # next_y - current_y -> number of "u" or "d" if negative
        movement_x = next_position[0] - current_position[0]
        movement_y = next_position[1] - current_position[1]
    
        
        # append number of r or l movements, 
        # then number of u or d movements, then p
        if movement_x > 0: # next position is to the right of current position
            movement_string += "r"*movement_x
        else: # next position is to the left of current position
            movement_string += "l"*abs(movement_x)
        if movement_y > 0: # next position is below current position
            movement_string += "d"*movement_y
        else: # next position is above current position
            movement_string += "u"*abs(movement_y)
        
        # press the key after moving there
        movement_string += "p" 

        # update current position after moving
        current_position = next_position
    return movement_string
        
def print_config(config):
    """
    Prints out the specified configuration
    """
    print("Configuration used:")
    print("-"*(len(config[0])+4))
    for i in range(len(config)):
        print("|", config[i], "|")
    print("-"*(len(config[0])+4))

# End of defined functions. Run the program
input_string = input("Enter a string to type: ")

# Store array of movement strings from each config and the best keyboard config
movement_strings = [None]*len(configs)
best_config = None
for i in range(len(configs)):
    movement_strings[i] = plan_movement(input_string, configs[i])
    # Check if string can be typed on this config
    if (movement_strings[i] == None):
        continue
    
    # Find best config (shortest movements to print string)
    if (best_config == None or len(movement_strings[i]) < len(movement_strings[best_config])):
        best_config = i

if best_config != None:
    # If movement string is not empty, print the best config 
    # and sequence to type it
    print_config(configs[best_config])    
    print("The robot must perform the following operations:\n"+movement_strings[best_config])
else: 
    #If movement string is None, string contained a character not in keyboard
    print("The string cannot be typed out.")

    
    

